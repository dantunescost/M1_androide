function n = numreg(S)
    n = size(find(S>0),1);
end