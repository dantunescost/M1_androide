function histon = normalise(histo)
  histon= histo/norm(histo);
end