function simMat= compute_similarities(listDes)
  simMat=listDes * listDes';
end