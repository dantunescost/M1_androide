function [R,G,B] = colormaps(I)
  R=I(:,:,1);
  G=I(:,:,2);
  B=I(:,:,3);
end